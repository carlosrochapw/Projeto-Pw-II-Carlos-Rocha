<section class="contato">
    <h1>Contato</h1>
    <p>Entre em contato conosco:</p>
    <ul>
        Email: <a href="mailto:contato@indiehub.com">contatoindiehub@gmail.com</a>
        Telefone: (51) 12345-6789
      Endereço: R. Gen. Balbão, 81 - Centro, Charqueadas
    </ul>
</section>
